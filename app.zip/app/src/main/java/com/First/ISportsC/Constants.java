package com.First.ISportsC;

public class Constants {

    public static final int ERROR_DIALOG_REQUEST = 9001;
}
